import "./App.css";
import SmartTaskApp from "./components/Home";

function App() {
  return <SmartTaskApp />;
}

export default App;
